package com.c12e.gocdhealth;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class Secrets {
 public static Properties getprops(){
	 Properties prop = new Properties();
	 try {
		 InputStream inputStream = new FileInputStream("config.properties");
		 prop.load(inputStream);
	 }
	 catch(Exception e){
		 e.printStackTrace();
	 }
	 return prop;
 }
}
