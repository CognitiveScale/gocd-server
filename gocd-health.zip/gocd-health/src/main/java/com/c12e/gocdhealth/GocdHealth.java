package com.c12e.gocdhealth;


import java.util.ArrayList;
import java.util.Properties;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response.Status;

import org.json.JSONArray;
import org.json.JSONObject;

import com.squareup.okhttp.Credentials;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

@Path("/")
public class GocdHealth {
	OkHttpClient client = new OkHttpClient();
	@SuppressWarnings("rawtypes")
	ArrayList state = new ArrayList();
	Properties creds = Secrets.getprops();
	
	/*
	 * Constructs a request to the gocd deployment using credentials
	 */
	Request request = new Request.Builder()
								 .url("http://"+creds.getProperty("url")+":8153/go/api/agents/")
								 .header("Authorization", Credentials.basic(creds.getProperty("user"), creds.getProperty("pass")))
								 .addHeader("Accept","application/vnd.go.cd.v2+json")
								 .build();
	/*
	 * Checks if we can get a response from the server
	 */
	@Path("/server")
	@GET
	public javax.ws.rs.core.Response server(){
		try {
			Response response = client.newCall(request).execute();
			if(response.isSuccessful())
			{
				return javax.ws.rs.core.Response.status(Status.OK).build();				
			}
			else
			{
				return javax.ws.rs.core.Response.status(Status.INTERNAL_SERVER_ERROR).build();								
			}
		} catch (Exception e) {
			e.printStackTrace();
			return javax.ws.rs.core.Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	/*
	 * Checks if all registered agents are healthy
	 */
	@Path("/agent")
	@GET
	public javax.ws.rs.core.Response agent(){
		try {
			int healthy= 0;
			Response response = client.newCall(request).execute();
			JSONObject agents = new JSONObject(response.body().string());
			JSONObject agent = agents.getJSONObject("_embedded");
			JSONArray  array = agent.getJSONArray("agents");
			for (int i=0; i< array.length(); i++){
				JSONObject ag = array.getJSONObject(i);				
				if(agenthealth(ag.getString("agent_state")) == true){
					healthy = healthy + 1;
				}
			}
			if(healthy == array.length())
			{
				return javax.ws.rs.core.Response.status(Status.OK).build();
			}
			else{
				return javax.ws.rs.core.Response.status(Status.GONE).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return javax.ws.rs.core.Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	/*
	 * Gets the string status of the agent and determines health
	 */
	public boolean agenthealth(String state) {
		  if (state != "Idle" || state != "Building") {
		    return true;
		  } else {
		    return false;
		  }
		}
}
