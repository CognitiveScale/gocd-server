# Health Check
There is a `config.properties` file in the root directory that has been redacted.<br>
Please fill it up appropriate contents of the file. To run the project simply `./gradlew jettyRunWar`

